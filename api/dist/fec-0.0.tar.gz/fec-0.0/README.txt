Simple FEC API wrapper
